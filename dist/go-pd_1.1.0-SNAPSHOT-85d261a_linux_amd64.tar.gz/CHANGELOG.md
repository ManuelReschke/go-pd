# Go-PD - Changelog

## v0.3.0

- add download func - GET /file/{id}

## v0.2.0

- use "debug" flag in file upload funcs
- PUT /file/{name} - file upload implemented
- write unit and integration tests
- refactor much stuff

### v0.1.0

- initial commit
- POST /file - file upload implemented
- write unit/integration test
